# 🛍️ URBAN STORE — Next.js Shop

## 🚀 Як запустити локально

```bash
# 1. Встанови залежності
npm install

# 2. Запусти сервер розробки
npm run dev

# 3. Відкрий у браузері
http://localhost:3000
```

## 📦 Як задеплоїти на Vercel

1. Завантаж проект на GitHub
2. Зайди на vercel.com
3. Натисни "New Project" → вибери репозиторій
4. Натисни "Deploy" — готово!

## ✏️ Як редагувати товари

Відкрий файл: `src/data/products.js`

Знайди товар і заміни:
- `👉 СЮДИ ВПИШИ НАЗВУ ТОВАРУ` → назва товару
- `0` в полі price → ціна числом (наприклад: `2990`)
- `👉 СЮДИ ВПИШИ ОПИС` → опис товару
- `👉 СЮДИ ВСТАВТЕ ПОСИЛАННЯ НА ФОТО` → пряме посилання на фото

## 🔧 Як додати нові товари

Просто скопіюй будь-який блок товару в `products.js` і зміни `id` на наступний номер.

## 🎨 Як змінити назву магазину

1. `src/app/layout.jsx` — змінити title
2. `src/components/Header.jsx` — знайти "URBANSTORE" і замінити
3. `src/app/page.jsx` — знайти логотип у footer

## 📁 Структура файлів

```
src/
├── app/
│   ├── page.jsx          ← Головна сторінка
│   ├── sneakers/page.jsx ← Кросівки
│   ├── clothes/page.jsx  ← Одяг
│   ├── accessories/page.jsx ← Аксесуари
│   └── cart/page.jsx     ← Кошик
├── components/
│   ├── Header.jsx        ← Навігація + dark mode
│   ├── ProductCard.jsx   ← Картка товару
│   ├── ProductRow.jsx    ← Горизонтальна стрічка
│   ├── CategoryPage.jsx  ← Сторінка категорії
│   └── PageTransition.jsx ← Анімація переходу
├── context/
│   └── CartContext.jsx   ← Кошик (localStorage)
└── data/
    └── products.js       ← ВСІ ТОВАРИ ТУТ
```
