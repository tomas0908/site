'use client'
import { useState } from 'react'
import { motion } from 'framer-motion'
import { useCart } from '@/context/CartContext'

const badgeColors = {
  NEW: 'bg-black text-white dark:bg-white dark:text-black',
  HIT: 'bg-yellow-400 text-black',
  SALE: 'bg-red-500 text-white',
}

export default function ProductCard({ product }) {
  const { addToCart } = useCart()
  const [selectedSize, setSelectedSize] = useState(null)
  const [added, setAdded] = useState(false)

  const handleAdd = () => {
    const size = selectedSize || product.sizes[0]
    addToCart(product, size)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <motion.div
      whileHover={{ y: -6 }}
      transition={{ duration: 0.25 }}
      className="group bg-gray-50 dark:bg-gray-900 rounded-2xl overflow-hidden flex flex-col"
    >
      {/* IMAGE */}
      <div className="relative aspect-[3/4] overflow-hidden bg-gray-100 dark:bg-gray-800">
        {product.image && !product.image.includes('👉') ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          // ЗАГЛУШКА поки нема фото
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-center p-4">
              <div className="text-4xl mb-2">
                {product.category === 'sneakers' ? '👟' : product.category === 'clothes' ? '👕' : '🎒'}
              </div>
              <p className="text-xs text-gray-400 font-mono">
                👉 ВСТАВТЕ ФОТО
              </p>
            </div>
          </div>
        )}
        {/* Badge */}
        {product.badge && (
          <span className={`absolute top-3 left-3 text-xs font-black px-2 py-1 rounded-full tracking-wider ${badgeColors[product.badge] || ''}`}>
            {product.badge}
          </span>
        )}
        {/* Gender tag */}
        <span className="absolute top-3 right-3 text-xs font-semibold px-2 py-1 rounded-full bg-white/80 dark:bg-black/80 text-gray-600 dark:text-gray-300">
          {product.gender === 'male' ? '♂ Чол' : '♀ Жін'}
        </span>
      </div>

      {/* INFO */}
      <div className="p-4 flex flex-col gap-3 flex-1">
        <div>
          <p className="font-bold text-sm leading-tight line-clamp-2">
            {product.name.includes('👉') ? (
              <span className="text-gray-300 dark:text-gray-600 font-mono text-xs">
                👉 ВПИШИ НАЗВУ ТОВАРУ
              </span>
            ) : product.name}
          </p>
        </div>

        {/* Sizes */}
        <div className="flex flex-wrap gap-1">
          {product.sizes.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSize(s)}
              className={`text-xs px-2 py-1 rounded border font-semibold transition-all duration-150 ${
                selectedSize === s
                  ? 'bg-black dark:bg-white text-white dark:text-black border-black dark:border-white'
                  : 'border-gray-200 dark:border-gray-700 hover:border-black dark:hover:border-white text-gray-500'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Price + Button */}
        <div className="flex items-center justify-between mt-auto pt-2 border-t border-gray-100 dark:border-gray-800">
          <span className="font-black text-lg">
            {product.price > 0 ? `${product.price.toLocaleString()} ₴` : (
              <span className="text-gray-300 dark:text-gray-600 font-mono text-xs">👉 ЦІНА</span>
            )}
          </span>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleAdd}
            className={`text-xs font-bold px-4 py-2 rounded-full transition-all duration-300 ${
              added
                ? 'bg-green-500 text-white'
                : 'bg-black dark:bg-white text-white dark:text-black hover:opacity-80'
            }`}
          >
            {added ? '✓ Додано' : 'В кошик'}
          </motion.button>
        </div>
      </div>
    </motion.div>
  )
}
