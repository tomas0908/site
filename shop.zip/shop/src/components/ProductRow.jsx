'use client'
import { useRef } from 'react'
import ProductCard from './ProductCard'

export default function ProductRow({ title, products, viewAllHref }) {
  const ref = useRef(null)

  const scroll = (dir) => {
    ref.current?.scrollBy({ left: dir * 320, behavior: 'smooth' })
  }

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black uppercase tracking-wider">{title}</h2>
          <div className="flex items-center gap-3">
            {viewAllHref && (
              <a
                href={viewAllHref}
                className="text-sm font-semibold text-gray-400 hover:text-black dark:hover:text-white transition-colors underline underline-offset-4"
              >
                Дивитись всі →
              </a>
            )}
            <button
              onClick={() => scroll(-1)}
              className="w-9 h-9 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all"
            >
              ←
            </button>
            <button
              onClick={() => scroll(1)}
              className="w-9 h-9 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all"
            >
              →
            </button>
          </div>
        </div>

        {/* Scrollable row */}
        <div
          ref={ref}
          className="flex gap-4 overflow-x-auto hide-scrollbar pb-2"
        >
          {products.map((p) => (
            <div key={p.id} className="flex-shrink-0 w-64">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
