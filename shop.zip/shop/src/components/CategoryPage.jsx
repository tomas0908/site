'use client'
import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import PageTransition from '@/components/PageTransition'
import ProductCard from '@/components/ProductCard'

export default function CategoryPage({ title, emoji, products }) {
  const [gender, setGender] = useState('all')
  const [sort, setSort] = useState('default')

  const filtered = useMemo(() => {
    let result = gender === 'all' ? products : products.filter((p) => p.gender === gender)
    if (sort === 'price-asc') result = [...result].sort((a, b) => a.price - b.price)
    if (sort === 'price-desc') result = [...result].sort((a, b) => b.price - a.price)
    return result
  }, [products, gender, sort])

  return (
    <PageTransition>
      {/* PAGE HERO */}
      <div className="bg-gray-50 dark:bg-gray-950 py-16 md:py-24 border-b border-gray-100 dark:border-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <p className="text-4xl mb-3">{emoji}</p>
            <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-2">{title}</h1>
            <p className="text-gray-400 font-semibold">{filtered.length} товарів</p>
          </motion.div>
        </div>
      </div>

      {/* FILTERS */}
      <div className="sticky top-16 z-40 bg-white/90 dark:bg-black/90 backdrop-blur-md border-b border-gray-100 dark:border-gray-900">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4 overflow-x-auto hide-scrollbar">
          {/* Gender filter */}
          <div className="flex gap-2 flex-shrink-0">
            {[
              { val: 'all', label: 'Всі' },
              { val: 'male', label: '♂ Чоловіче' },
              { val: 'female', label: '♀ Жіноче' },
            ].map((g) => (
              <button
                key={g.val}
                onClick={() => setGender(g.val)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                  gender === g.val
                    ? 'bg-black dark:bg-white text-white dark:text-black'
                    : 'bg-gray-100 dark:bg-gray-900 text-gray-500 hover:text-black dark:hover:text-white'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>

          {/* Sort */}
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="text-xs font-semibold bg-transparent border border-gray-200 dark:border-gray-800 rounded-full px-3 py-1.5 outline-none flex-shrink-0"
          >
            <option value="default">За замовчуванням</option>
            <option value="price-asc">Ціна: від низької</option>
            <option value="price-desc">Ціна: від високої</option>
          </select>
        </div>
      </div>

      {/* PRODUCTS GRID */}
      <div className="max-w-7xl mx-auto px-4 py-10">
        {filtered.length === 0 ? (
          <div className="text-center py-24 text-gray-400">
            <p className="text-5xl mb-4">🔍</p>
            <p className="font-bold text-lg">Товарів не знайдено</p>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6"
          >
            {filtered.map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <ProductCard product={p} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </PageTransition>
  )
}
