'use client'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import { useCart } from '@/context/CartContext'
import PageTransition from '@/components/PageTransition'

export default function CartPage() {
  const { cart, removeFromCart, updateQty, total } = useCart()

  return (
    <PageTransition>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-10">
          Кошик
          {cart.length > 0 && (
            <span className="text-gray-300 dark:text-gray-700 ml-4 text-3xl">
              ({cart.length})
            </span>
          )}
        </h1>

        {cart.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-7xl mb-6">🛒</p>
            <p className="text-xl font-bold text-gray-400 mb-8">Кошик порожній</p>
            <Link
              href="/"
              className="inline-block px-10 py-4 bg-black dark:bg-white text-white dark:text-black font-black uppercase tracking-widest text-sm rounded-full hover:scale-105 transition-transform"
            >
              Продовжити покупки
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            {/* ITEMS */}
            <div className="md:col-span-2 flex flex-col gap-4">
              <AnimatePresence>
                {cart.map((item) => (
                  <motion.div
                    key={item.key}
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="flex gap-4 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl"
                  >
                    {/* Image */}
                    <div className="w-24 h-28 bg-gray-100 dark:bg-gray-800 rounded-xl flex-shrink-0 overflow-hidden">
                      {item.image && !item.image.includes('👉') ? (
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-2xl">
                          {item.category === 'sneakers' ? '👟' : item.category === 'clothes' ? '👕' : '🎒'}
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm leading-tight mb-1 truncate">
                        {item.name.includes('👉') ? 'Товар' : item.name}
                      </p>
                      <p className="text-xs text-gray-400 mb-3">Розмір: {item.size}</p>

                      {/* Qty */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQty(item.key, item.qty - 1)}
                          className="w-7 h-7 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center text-sm font-bold hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all"
                        >
                          −
                        </button>
                        <span className="w-8 text-center font-bold text-sm">{item.qty}</span>
                        <button
                          onClick={() => updateQty(item.key, item.qty + 1)}
                          className="w-7 h-7 rounded-full border border-gray-200 dark:border-gray-700 flex items-center justify-center text-sm font-bold hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Price + Remove */}
                    <div className="flex flex-col items-end justify-between">
                      <button
                        onClick={() => removeFromCart(item.key)}
                        className="text-gray-300 dark:text-gray-600 hover:text-red-500 transition-colors text-lg leading-none"
                      >
                        ×
                      </button>
                      <p className="font-black text-base">
                        {item.price > 0 ? `${(item.price * item.qty).toLocaleString()} ₴` : '—'}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* ORDER SUMMARY */}
            <div className="md:col-span-1">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-2xl p-6 sticky top-24">
                <h2 className="font-black text-lg uppercase tracking-wider mb-6">Разом</h2>
                <div className="flex justify-between mb-2 text-sm">
                  <span className="text-gray-400">Товари ({cart.reduce((s,i)=>s+i.qty,0)} шт)</span>
                  <span className="font-semibold">{total > 0 ? `${total.toLocaleString()} ₴` : '—'}</span>
                </div>
                <div className="flex justify-between mb-6 text-sm">
                  <span className="text-gray-400">Доставка</span>
                  <span className="font-semibold text-green-500">Безкоштовно</span>
                </div>
                <div className="flex justify-between font-black text-xl mb-6 pt-4 border-t border-gray-200 dark:border-gray-800">
                  <span>Підсумок</span>
                  <span>{total > 0 ? `${total.toLocaleString()} ₴` : '—'}</span>
                </div>
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  className="w-full py-4 bg-black dark:bg-white text-white dark:text-black font-black uppercase tracking-widest text-sm rounded-full hover:opacity-90 transition-opacity"
                >
                  {/* 👉 СЮДИ ВПИШИ ТЕКСТ КНОПКИ ЗАМОВЛЕННЯ */}
                  Оформити замовлення
                </motion.button>
                <Link
                  href="/"
                  className="block text-center mt-4 text-sm text-gray-400 hover:text-black dark:hover:text-white transition-colors font-semibold"
                >
                  ← Продовжити покупки
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </PageTransition>
  )
}
