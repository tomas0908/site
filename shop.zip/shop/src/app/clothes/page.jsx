import CategoryPage from '@/components/CategoryPage'
import { getByCategory } from '@/data/products'

export const metadata = { title: 'Одяг' }

export default function ClothesPage() {
  const products = getByCategory('clothes')
  return <CategoryPage title="Одяг" emoji="👕" products={products} />
}
