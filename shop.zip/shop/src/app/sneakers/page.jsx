import CategoryPage from '@/components/CategoryPage'
import { getByCategory } from '@/data/products'

export const metadata = { title: 'Кросівки' }

export default function SneakersPage() {
  const products = getByCategory('sneakers')
  return <CategoryPage title="Кросівки" emoji="👟" products={products} />
}
