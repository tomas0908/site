import { Inter } from 'next/font/google'
import './globals.css'
import { CartProvider } from '@/context/CartContext'
import Header from '@/components/Header'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: '👉 СЮДИ ВПИШИ НАЗВУ МАГАЗИНУ', // Наприклад: URBAN STORE
  description: '👉 СЮДИ ВПИШИ ОПИС МАГАЗИНУ',
}

export default function RootLayout({ children }) {
  return (
    <html lang="uk" suppressHydrationWarning>
      <body className={`${inter.className} bg-white dark:bg-black text-black dark:text-white transition-colors duration-300`}>
        <CartProvider>
          <Header />
          <main className="min-h-screen pt-16">
            {children}
          </main>
        </CartProvider>
      </body>
    </html>
  )
}
