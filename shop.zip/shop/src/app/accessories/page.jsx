import CategoryPage from '@/components/CategoryPage'
import { getByCategory } from '@/data/products'

export const metadata = { title: 'Аксесуари' }

export default function AccessoriesPage() {
  const products = getByCategory('accessories')
  return <CategoryPage title="Аксесуари" emoji="🎒" products={products} />
}
