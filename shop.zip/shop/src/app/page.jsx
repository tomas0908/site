'use client'
import { useMemo } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import PageTransition from '@/components/PageTransition'
import ProductRow from '@/components/ProductRow'
import ProductCard from '@/components/ProductCard'
import { products, getByCategory, getByGender, getShuffled } from '@/data/products'

export default function HomePage() {
  const sneakers = useMemo(() => getShuffled(getByCategory('sneakers')), [])
  const clothes = useMemo(() => getShuffled(getByCategory('clothes')), [])
  const accessories = useMemo(() => getShuffled(getByCategory('accessories')), [])
  const menProducts = useMemo(() => getShuffled(getByGender('male')).slice(0, 4), [])
  const womenProducts = useMemo(() => getShuffled(getByGender('female')).slice(0, 4), [])

  return (
    <PageTransition>
      {/* ══════════════════════════════════════ */}
      {/* HERO SECTION */}
      {/* ══════════════════════════════════════ */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-950">

        {/* 👉 СЮДИ ВСТАВТЕ ГОЛОВНЕ ФОТО (HERO IMAGE) */}
        {/* Щоб додати фото — розкоментуй рядки нижче і вставте посилання */}
        {/*
        <img
          src="👉 СЮДИ ВСТАВТЕ ПОСИЛАННЯ НА ФОТО"
          alt="Hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        */}

        {/* Placeholder фон поки немає фото */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 via-gray-50 to-gray-200 dark:from-gray-900 dark:via-gray-950 dark:to-black" />

        {/* HERO CONTENT */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-sm font-bold tracking-[6px] uppercase text-gray-400 mb-6"
          >
            {/* 👉 СЮДИ ВПИШИ ПІДЗАГОЛОВОК (наприклад: Нова колекція 2025) */}
            НОВА КОЛЕКЦІЯ 2025
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-6xl md:text-8xl lg:text-[10rem] font-black uppercase leading-none tracking-tighter mb-8"
          >
            {/* 👉 СЮДИ ВПИШИ ГОЛОВНИЙ ЗАГОЛОВОК */}
            JUST<br />
            <span className="text-gray-300 dark:text-gray-700">YOUR</span><br />
            STYLE
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35 }}
            className="text-lg text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-10"
          >
            {/* 👉 СЮДИ ВПИШИ ОПИС ПІД ЗАГОЛОВКОМ */}
            Streetwear для тих, хто не вписується в рамки
          </motion.p>

          {/* 👉 КНОПКИ */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              href="/sneakers"
              className="px-10 py-4 bg-black dark:bg-white text-white dark:text-black font-black uppercase tracking-widest text-sm rounded-full hover:scale-105 transition-transform duration-200"
            >
              Дивитись колекцію
            </Link>
            <Link
              href="/clothes"
              className="px-10 py-4 border-2 border-black dark:border-white font-black uppercase tracking-widest text-sm rounded-full hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-all duration-200"
            >
              {/* 👉 СЮДИ ВПИШИ ТЕКСТ ДРУГОЇ КНОПКИ */}
              Одяг
            </Link>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-gray-400"
        >
          ↓
        </motion.div>
      </section>

      {/* ══════════════════════════════════════ */}
      {/* CATEGORY BANNERS */}
      {/* ══════════════════════════════════════ */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { href: '/sneakers', label: 'Кросівки', emoji: '👟', bg: 'bg-gray-100 dark:bg-gray-900' },
            { href: '/clothes', label: 'Одяг', emoji: '👕', bg: 'bg-black text-white dark:bg-white dark:text-black' },
            { href: '/accessories', label: 'Аксесуари', emoji: '🎒', bg: 'bg-gray-100 dark:bg-gray-900' },
          ].map((cat) => (
            <Link key={cat.href} href={cat.href}>
              <motion.div
                whileHover={{ scale: 1.02 }}
                className={`${cat.bg} rounded-3xl p-10 flex flex-col items-center justify-center gap-4 aspect-square cursor-pointer transition-all`}
              >
                <span className="text-5xl">{cat.emoji}</span>
                <span className="font-black text-xl uppercase tracking-widest">{cat.label}</span>
                <span className="text-sm opacity-50 font-semibold">Дивитись →</span>
              </motion.div>
            </Link>
          ))}
        </div>
      </section>

      {/* ══════════════════════════════════════ */}
      {/* PRODUCT ROWS (DORIZHKY) */}
      {/* ══════════════════════════════════════ */}
      <ProductRow title="👟 Кросівки" products={sneakers} viewAllHref="/sneakers" />
      <ProductRow title="👕 Одяг" products={clothes} viewAllHref="/clothes" />
      <ProductRow title="🎒 Аксесуари" products={accessories} viewAllHref="/accessories" />

      {/* ══════════════════════════════════════ */}
      {/* GENDER SECTION */}
      {/* ══════════════════════════════════════ */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-black uppercase tracking-wider mb-10 text-center">Колекції</h2>

        {/* ЧОЛОВІЧЕ */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-6">
            <span className="text-2xl font-black uppercase tracking-widest">♂ Чоловіче</span>
            <span className="h-px flex-1 bg-gray-200 dark:bg-gray-800"/>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {menProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>

        {/* ЖІНОЧЕ */}
        <div>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-2xl font-black uppercase tracking-widest">♀ Жіноче</span>
            <span className="h-px flex-1 bg-gray-200 dark:bg-gray-800"/>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {womenProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════ */}
      {/* BOTTOM BANNER */}
      {/* ══════════════════════════════════════ */}
      <section className="bg-black dark:bg-white text-white dark:text-black py-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto px-4"
        >
          <p className="text-sm font-bold tracking-[6px] uppercase opacity-50 mb-4">
            {/* 👉 СЮДИ ВПИШИ ТЕКСТ НАД ЗАГОЛОВКОМ */}
            Лімітована пропозиція
          </p>
          <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6">
            {/* 👉 СЮДИ ВПИШИ ЗАГОЛОВОК БАНЕРУ */}
            ЗНИЖКА<br/>ДО -50%
          </h2>
          <Link
            href="/sneakers"
            className="inline-block px-10 py-4 bg-white dark:bg-black text-black dark:text-white font-black uppercase tracking-widest text-sm rounded-full hover:scale-105 transition-transform"
          >
            Отримати знижку
          </Link>
        </motion.div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-gray-100 dark:border-gray-900 py-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
          <span className="font-black text-xl uppercase tracking-widest text-black dark:text-white">
            {/* 👉 СЮДИ ВПИШИ НАЗВУ */}
            URBAN<span className="text-gray-400">STORE</span>
          </span>
          <p>
            {/* 👉 СЮДИ ВПИШИ КОПІРАЙТ */}
            © 2025 Urban Store. Всі права захищено.
          </p>
          <div className="flex gap-6">
            {/* 👉 СЮДИ ВПИШИ ПОСИЛАННЯ НА СОЦМЕРЕЖІ */}
            <a href="#" className="hover:text-black dark:hover:text-white transition-colors">Instagram</a>
            <a href="#" className="hover:text-black dark:hover:text-white transition-colors">TikTok</a>
            <a href="#" className="hover:text-black dark:hover:text-white transition-colors">Telegram</a>
          </div>
        </div>
      </footer>
    </PageTransition>
  )
}
